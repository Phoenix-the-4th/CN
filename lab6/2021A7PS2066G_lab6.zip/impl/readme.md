# LAB6_MULTITHREADING_FILES_23-24_TAKEHOME

## Instructions to run
- First compile and start server.c - ./a.out <ip_address> <port> <password>
- Then individually start all the clients(compile client.c first) in seperate terminals by ./a.out <ip_address> <port>
- Enter client inputs in given format isn question <username>@<ip_address>|<authority>
- If ip address is not of correct format client exits
- If client is root enter password, if normal can continue regular operations
- If password incorrect recieves error message from server and exit, if correct continue regular operations